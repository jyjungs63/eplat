# summernote-img-upload
Modified summernote wysiwyg editor to upload images to filesystem and display in the editor.

This is a working example of image upload feature.

The original summernote converts uploaded images to base64 format.

This editor uploads images to the file system, 
Just make sure that you have write access to img-uploads folder.

https://github.com/summernote/summernote
