export default {
	method: "GET",
};